function knobCalculator(km){
    var knob=km*0.539956803455724;
    console.log(knob.toFixed(2));
}
knobCalculator(20);
knobCalculator(112);
knobCalculator(400);